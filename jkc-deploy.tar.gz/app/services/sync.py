import json
import threading
import time
from datetime import date, timedelta

from nonebot.log import logger
from sqlalchemy import delete, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..db import get_session
from ..models.checkin_day import CheckinDay
from ..models.checkin_log import CheckinLog
from ..models.daily_record import DailyRecord
from ..models.manual_distance import ManualDistance
from ..models.member import Member
from . import checkin, timeutil
from .providers import get_provider
from .providers.base import DailyStats


def _write_record(
    qq: str, d: date, platform: str, stats: DailyStats, session: Session
) -> DailyStats:
    """把一份 DailyStats upsert 到 daily_record（同成员+日期+平台覆盖）。"""
    rec = session.execute(
        select(DailyRecord).where(
            DailyRecord.member_qq == qq,
            DailyRecord.record_date == d,
            DailyRecord.platform == platform,
        )
    ).scalar_one_or_none()
    if rec is None:
        rec = DailyRecord(member_qq=qq, record_date=d, platform=platform)
        session.add(rec)
        try:
            # 提前 flush 触发 uq_daily_member_date_platform，捕获并发 upsert 竞态
            # （后台回填历史 + 用户查询同时落库时，两个线程可能同时 select 到 None）。
            session.flush()
        except IntegrityError:
            # 别人已抢先插入：回滚本次 pending，重查已有行后覆盖
            session.rollback()
            rec = session.execute(
                select(DailyRecord).where(
                    DailyRecord.member_qq == qq,
                    DailyRecord.record_date == d,
                    DailyRecord.platform == platform,
                )
            ).scalar_one_or_none()
            if rec is None:
                raise

    rec.steps = stats.steps
    rec.distance_km = stats.distance_km
    rec.active_minutes = stats.active_minutes
    rec.calories = stats.calories
    rec.resting_hr = stats.resting_hr
    rec.sleep_hours = stats.sleep_hours
    rec.activities_count = stats.activities_count
    rec.ascent_meters = stats.ascent_meters
    rec.training_load = stats.training_load
    rec.avg_pace_sec_per_km = stats.avg_pace_sec_per_km
    rec.avg_hr = stats.avg_hr
    rec.max_activity_distance_km = stats.max_activity_distance_km
    rec.raw_json = json.dumps(stats.raw or {}, ensure_ascii=False)
    # 只有「有运动数据」才记打卡日（统一口径 is_active_day：距离/时长/消耗任一项>0），
    # 避免绑定成员当天没运动、仅同步到全天步数/卡路里也被误记为打卡。
    if checkin.is_active_day(stats.distance_km, stats.active_minutes, stats.calories):
        checkin.ensure_day(qq, d, session)
    session.commit()
    return stats


def sync_daily(qq: str, platform: str, d: date) -> DailyStats:
    """从平台拉取某成员某天数据，并 upsert 到 daily_record。

    内部自开 session（阻塞的网络 + 数据库调用），供 asyncio.to_thread 直接执行，
    避免把主线程的 Session 传入线程（违反 SQLAlchemy 线程安全约定）。
    """
    provider = get_provider(platform)
    # 每用户凭据以 QQ 为键，fetch_daily 第一参传成员 QQ
    stats = provider.fetch_daily(qq, d)
    session = get_session()
    try:
        return _write_record(qq, d, provider.name, stats, session)
    finally:
        session.close()


def record_manual_activity(
    member: Member, d: date, stats: DailyStats, session: Session
) -> DailyRecord:
    """把一张截图识别到的**单次运动**累加进当日明细（platform="manual"）。

    与平台接口不同，截图一次代表一次运动，因此：
      - distance / ascent / calories / active_minutes **累加**；
      - max_activity_distance_km 取历史与本次的**较大值**；
      - avg_pace/avg_hr 简单以本次覆盖（无更细数据可加权）。
    供每日排行把「未绑定平台、靠截图记录」的成员也纳入统计。
    入参 stats 为统一 DailyStats（调用方从 parsers 结果构造），与平台接口同形。
    纯 SQLite 单条写入、极快，直接同步调用即可（勿传入线程，避免跨线程共享 Session）。
    """
    rec = session.execute(
        select(DailyRecord).where(
            DailyRecord.member_qq == member.qq,
            DailyRecord.record_date == d,
            DailyRecord.platform == "manual",
        )
    ).scalar_one_or_none()
    if rec is None:
        rec = DailyRecord(member_qq=member.qq, record_date=d, platform="manual")
        session.add(rec)

    distance = stats.distance_km
    # 新建的 DailyRecord 尚未 flush，各列仍是 None（default=0.0 只在 INSERT 时生效），
    # 因此累加前必须用 `or 0` 兜底，否则 None + float 会抛 TypeError。
    rec.distance_km = round((rec.distance_km or 0.0) + distance, 2)
    rec.ascent_meters = round((rec.ascent_meters or 0.0) + stats.ascent_meters, 2)
    rec.calories = (rec.calories or 0) + stats.calories
    rec.active_minutes = (rec.active_minutes or 0) + stats.active_minutes
    rec.max_activity_distance_km = round(max(rec.max_activity_distance_km or 0.0, distance), 2)
    if stats.avg_pace_sec_per_km:
        rec.avg_pace_sec_per_km = stats.avg_pace_sec_per_km
    if stats.avg_hr:
        rec.avg_hr = stats.avg_hr
    rec.activities_count = (rec.activities_count or 0) + 1
    checkin.ensure_day(member.qq, d, session)
    # 只 flush 不 commit，理由同 add_manual_distance：截图写库路径单事务。
    session.flush()
    return rec


def log_checkin(
    qq: str,
    d: date,
    distance_km: float,
    session: Session,
    *,
    ascent_meters: float = 0.0,
    calories: int = 0,
    active_minutes: int = 0,
) -> None:
    """记录一次截图打卡的明细（供「删除最近一次打卡」精确回退）。

    只 flush 不 commit，理由同 add_manual_distance：截图写库路径单事务。
    """
    session.add(
        CheckinLog(
            member_qq=qq,
            record_date=d,
            distance_km=distance_km,
            ascent_meters=ascent_meters,
            calories=calories,
            active_minutes=active_minutes,
        )
    )
    session.flush()


def _undo_checkin_log(session: Session, log: CheckinLog) -> tuple[float, date]:
    """撤销一条**指定**截图打卡记录，返回 (回退距离, 打卡日期)。

    完整回退四处，保证累计里程 / 当日明细 / 打卡天数一致：
      1. manual_distance：total / 本周累计各扣回该次距离（跨周时本周值可能已重置，只扣本周一的）；
      2. daily_record(platform="manual")：扣回距离/爬升/消耗/时长、次数减一，
         并重建 max_activity_distance_km（= 该日剩余截图的单次最长），无数据则删行；
      3. checkin_log：删除这条明细；
      4. checkin_day：该日若已无任何运动数据（含其它平台），删除打卡日，累计天数随之减少。
    SQLite 单条删除极快，可直接在事件循环内同步执行。
    """
    qq = log.member_qq
    dist = log.distance_km or 0.0
    ascent = log.ascent_meters or 0.0
    cal = log.calories or 0
    mins = log.active_minutes or 0
    d = log.record_date

    md = session.get(ManualDistance, qq)
    if md is not None:
        md.total_distance_km = round(max(0.0, (md.total_distance_km or 0.0) - dist), 2)
        that_monday = d - timedelta(days=d.weekday())
        if md.week_start == that_monday:
            md.week_distance_km = round(max(0.0, (md.week_distance_km or 0.0) - dist), 2)

    # 先删这条明细并落库，让下方「重建 max」与「判断当日是否还有数据」只看到剩余截图
    session.delete(log)
    session.flush()

    rec = session.execute(
        select(DailyRecord).where(
            DailyRecord.member_qq == qq,
            DailyRecord.record_date == d,
            DailyRecord.platform == "manual",
        )
    ).scalar_one_or_none()
    if rec is not None:
        rec.activities_count = max(0, (rec.activities_count or 0) - 1)
        rec.distance_km = round(max(0.0, (rec.distance_km or 0.0) - dist), 2)
        rec.ascent_meters = round(max(0.0, (rec.ascent_meters or 0.0) - ascent), 2)
        rec.calories = max(0, (rec.calories or 0) - cal)
        rec.active_minutes = max(0, (rec.active_minutes or 0) - mins)
        remaining_km = (
            session.execute(
                select(CheckinLog.distance_km).where(
                    CheckinLog.member_qq == qq, CheckinLog.record_date == d
                )
            )
            .scalars()
            .all()
        )
        rec.max_activity_distance_km = round(max(remaining_km, default=0.0), 2)
        if (rec.activities_count or 0) <= 0 and not checkin.is_active_day(
            rec.distance_km, rec.active_minutes, rec.calories
        ):
            session.delete(rec)
            # 让下方 others 查询也能看到该行已删，正确判定当日是否还有任何运动数据
            session.flush()

    # 该日若已无任何运动数据（含其它平台），删除打卡日
    others = (
        session.execute(
            select(DailyRecord).where(DailyRecord.member_qq == qq, DailyRecord.record_date == d)
        )
        .scalars()
        .all()
    )
    if not any(checkin.is_active_day(r.distance_km, r.active_minutes, r.calories) for r in others):
        session.execute(
            delete(CheckinDay).where(CheckinDay.member_qq == qq, CheckinDay.record_date == d)
        )

    session.commit()
    return dist, d


def undo_last_checkin(qq: str, session: Session) -> tuple[float, date | None]:
    """撤销某成员最近一次截图打卡，返回 (回退距离, 打卡日期)；无记录返回 (0.0, None)。"""
    last = (
        session.execute(
            select(CheckinLog).where(CheckinLog.member_qq == qq).order_by(CheckinLog.id.desc())
        )
        .scalars()
        .first()
    )
    if last is None:
        return 0.0, None
    return _undo_checkin_log(session, last)


def undo_checkin_by_id(qq: str, checkin_log_id: int, session: Session) -> tuple[float, date] | None:
    """删除某成员**指定 id** 的截图打卡记录（管理员用），返回 (回退距离, 打卡日期)。

    记录不存在或不属于该成员时返回 None（不做任何修改）。与 undo_last_checkin 共用
    _undo_checkin_log，回退逻辑完全一致，只是定位到「任意一条」而非「最近一条」。
    """
    log = session.get(CheckinLog, checkin_log_id)
    if log is None or log.member_qq != qq:
        return None
    return _undo_checkin_log(session, log)


def add_manual_distance(member: Member, distance_km: float, session: Session) -> float:
    """把识别到的距离累加到成员的累计里程，返回累加后的总里程。

    同时维护两条链：
      - total_distance_km：历史总累计（供「今日」展示）；
      - week_distance_km：本周累计（供周排行），跨周自动清零重计。
    未绑定平台的成员通过截图手动记录时使用；只存距离和，不留明细。
    纯 SQLite 单条写入、极快，直接同步调用即可（勿传入线程，避免跨线程共享 Session）。
    """
    rec = session.get(ManualDistance, member.qq)
    if rec is None:
        rec = ManualDistance(member_qq=member.qq, total_distance_km=0.0, week_distance_km=0.0)
        session.add(rec)

    # 跨周重置：当前周一与记录的 week_start 不一致时，本周累计清零、更新周起始
    today = timeutil.today()
    this_monday = today - timedelta(days=today.weekday())
    if rec.week_start != this_monday:
        rec.week_start = this_monday
        rec.week_distance_km = 0.0

    rec.total_distance_km = round(rec.total_distance_km + distance_km, 2)
    rec.week_distance_km = round(rec.week_distance_km + distance_km, 2)
    # 只 flush 不 commit：与截图写库路径其它步骤同属一个事务，由调用方最后统一 commit，
    # 避免中间某步失败造成「前半已落库、去重未标记 → 重发重复累计」。
    session.flush()
    return rec.total_distance_km


def get_manual_distance(member_qq: str, session: Session) -> float:
    """查询成员的累计里程（无记录返回 0.0）。"""
    rec = session.get(ManualDistance, member_qq)
    return rec.total_distance_km if rec else 0.0


def get_week_distance(member_qq: str, session: Session) -> float:
    """查询成员本周累计里程（本周尚未记录时返回 0.0）。

    week_distance_km 只在「本周有新增截图」时被 add_manual_distance 重置为本周值，
    若 week_start 不是本周一，说明该值仍是上周旧值，不能当作本周累计展示。
    """
    rec = session.get(ManualDistance, member_qq)
    if rec is None or not rec.week_distance_km:
        return 0.0
    this_monday = timeutil.today() - timedelta(days=timeutil.today().weekday())
    return round(rec.week_distance_km, 2) if rec.week_start == this_monday else 0.0


def clear_member_records(session: Session, qq: str) -> int:
    """删除某成员的全部运动明细（各平台 + 截图）与累计里程。

    绑定/解绑平台时调用：旧数据应由新平台数据取代，避免残留旧数据（截图或
    上一个平台）继续混入排行、造成重复累加。返回删除的 daily_record 行数。
    """
    n = session.execute(delete(DailyRecord).where(DailyRecord.member_qq == qq)).rowcount or 0
    session.execute(delete(ManualDistance).where(ManualDistance.member_qq == qq))
    session.execute(delete(CheckinLog).where(CheckinLog.member_qq == qq))
    session.commit()
    return n


def sync_history(qq: str, platform: str, start: date, end: date) -> int:
    """把 [start, end) 区间的平台数据逐日回填进 daily_record（幂等 upsert）。

    绑定平台 / 管理员同步时调用，补齐历史明细，供周榜（7 天）/月榜（最多 31 天）
    聚合出正确结果。内部自开 session（阻塞的网络 + 数据库调用），供 asyncio.to_thread
    直接执行。通过 provider.fetch_range 拉取——平台可实现「登录一次复用会话」
    （如 Garmin 回填一个月历史只需登录一次），单日失败不影响其它日期。返回成功回填天数。
    """
    provider = get_provider(platform)
    session = get_session()
    try:
        try:
            stats_list = provider.fetch_range(qq, start, end)
        except Exception as e:
            logger.warning(f"回填 {qq}（{provider.name}）失败: {e}")
            return 0
        done = 0
        for stats in stats_list:
            _write_record(qq, stats.date, provider.name, stats, session)
            done += 1
        return done
    finally:
        session.close()


def sync_today_all(exclude_qq: str | None = None) -> int:
    """同步**所有已绑定成员**的今日数据，返回成功同步的人数。

    榜单播报 / 手动「排行」在计算榜单前调用，保证当天数据新鲜——否则绑定 COROS 后
    榜单会因为还没回填到今天而显示空。逐成员调用 sync_daily（各自自开 session），
    单成员失败不影响其它成员。阻塞（网络 + DB），供 asyncio.to_thread 直接执行。

    exclude_qq：传某成员 QQ 时可跳过该成员——「今日」命令已单独 sync_daily 过本人，
    再全量同步一遍纯属重复拉取，跳过可省一次登录/网络往返。
    """
    global _sync_today_all_at
    _sync_today_all_at = time.time()  # 记录本次全量同步时刻，供节流复用
    session = get_session()
    try:
        targets = [
            (m.qq, m.platform)
            for m in session.execute(select(Member).where(Member.platform != "")).scalars().all()
        ]
    finally:
        session.close()

    today = timeutil.today()
    ok = 0
    for qq, platform in targets:
        if exclude_qq is not None and qq == exclude_qq:
            continue
        try:
            sync_daily(qq, platform, today)
            ok += 1
        except Exception as e:
            logger.warning(f"同步 {qq}（{platform}）今日数据失败: {e}")
    return ok


# 全量同步的进程内节流时间戳（bot 单进程运行，模块级即可）。「今日群内第 N 名」这类
# 高频交互场景需要全群当天数据齐全（截图/绑定成员同口径），但没必要每次都拉全成员
# 平台接口——距上次全量同步不足 _SYNC_TODAY_ALL_MIN_INTERVAL_SEC 秒就复用上次结果。
_sync_today_all_at = 0.0
_SYNC_TODAY_ALL_MIN_INTERVAL_SEC = 600.0  # 10 分钟
# 全量同步互斥锁：多个成员同时查「今日」会各自触发一次全量同步（查询风暴）。
# 阻塞获取——等前一轮同步真正落库完成后再判断是否复用，避免调用方读到不含增量的旧数据。
_sync_today_all_lock = threading.Lock()


def sync_today_all_throttled(
    min_interval_sec: float = _SYNC_TODAY_ALL_MIN_INTERVAL_SEC,
    exclude_qq: str | None = None,
) -> int:
    """带节流的全量同步：距上次全量同步不足 min_interval_sec 秒则跳过，返回 0。

    供「今日群内第 N 名」等高频名次场景调用，避免每次截图/今日查询都拉全成员平台接口；
    榜单播报与「排行」命令仍走无节流的 sync_today_all 保证最终口径。
    exclude_qq 透传给 sync_today_all：跳过调用方已单独同步过的本人。

    单飞保证（阻塞等锁）：用互斥锁串行化，避免并发查询风暴时多个线程同时跑全量同步、
    重复登录同一批平台账号。这里**阻塞等待**而非拿不到就返回——正在进行的这一轮同步
    尚未落库，直接返回会让调用方读到不含本轮增量的旧数据（「截图与 App 名次对不上」）。
    等锁后本轮写入已 commit，再按时间戳判断是否复用，名次口径严格一致。
    调用方都在 asyncio.to_thread 内，线程内阻塞安全（不卡事件循环）。
    """
    if time.time() - _sync_today_all_at < min_interval_sec:
        return 0
    with _sync_today_all_lock:
        # 双重检查：等锁期间前一轮可能已完成并推进时间戳 → 直接复用其结果
        if time.time() - _sync_today_all_at < min_interval_sec:
            return 0
        return sync_today_all(exclude_qq=exclude_qq)
