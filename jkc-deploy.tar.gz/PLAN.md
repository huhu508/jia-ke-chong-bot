# 甲壳虫 —— 架构设计与路线图

本文档描述「甲壳虫」QQ 群运动机器人的整体设计、分层结构、核心取舍与后续计划。面向后续维护者与协作者。

## 1. 项目定位

一个长期在线的 QQ 群运动搭子：把多个运动平台的数据（Garmin / 高驰 COROS / 截图 OCR）汇聚到群里，提供个人查询、三榜排行与定时播报，并用大模型做「说人话」的解读。

核心价值不是「做一个数据面板」，而是**降低群成员记录与展示运动数据的摩擦**：

- 已接入平台的成员：绑定一次，之后「今日 / 周数据 / 总结」随时查；
- 未接入平台的成员：发一张运动截图即可自动记录、进入排行；
- 全部交互用一句命令 / 一张图完成，不用跳转 App。

## 2. 技术选型

| 环节 | 选型 | 理由 |
|---|---|---|
| 机器人框架 | NoneBot2 + OneBot v11 适配器 | 生态成熟、插件化、命令/消息双模式 |
| 协议端 | NapCat（反向 WebSocket） | 扫码登录、无需协议密码，稳定接入 QQ |
| 数据存储 | SQLAlchemy 2.0 + SQLite | 单文件、零运维、够用；`Session` 按需创建 |
| OCR | RapidOCR（rapidocr-onnxruntime） | **本地**识别，截图数据不出本机 |
| 平台 SDK | garminconnect / COROS 官方 MCP | 佳明仅邮箱登录；COROS 走 OAuth 授权码 + PKCE |
| 大模型 | Agnes AI（OpenAI 兼容） | 国产、`agnes-3.0-flash`、接口稳定 |
| 配置 | pydantic-settings | 类型安全读 `.env` |
| 代码质量 | ruff（format + lint） | 单工具覆盖格式化 / 静态检查 / 导入排序 |

## 3. 架构分层

```
┌─────────────────────────────────────────────────────┐
│ 协议层   NoneBot2 + OneBot v11 适配器（NapCat 反向 WS）│
├─────────────────────────────────────────────────────┤
│ 插件层   app/plugins（14 个：命令处理器 + 消息处理器） │
│          admin / activity / checkin / diagnose /     │
│          gate / group_tracker / history / image_ocr/ │
│          interact / lottery / profile / query /      │
│          ranking / summary                           │
├─────────────────────────────────────────────────────┤
│ 服务层   app/services（业务逻辑，与 NoneBot 解耦）     │
│          activity · checkin · cheers · credentials · │
│          crypto · diagnose · llm · member · ocr ·    │
│          parsers · permission · ranking · retention ·│
│          summary · sync · tasks · timeutil ·         │
│          providers/                                  │
├─────────────────────────────────────────────────────┤
│ 数据层   app/models（SQLAlchemy ORM）+ SQLite         │
└─────────────────────────────────────────────────────┘
```

**分层原则**：插件层只做「收发消息 + 编排」，可复用的业务逻辑全部下沉到服务层；服务层不依赖 `Bot`/`Event`，便于单独测试与复用。

## 4. 核心设计原则

### 4.1 大模型「生态位」：只做增强层

LLM 被严格限制在**核心数据链路之外**：

- **确定性链路**（不依赖 LLM）：OCR 识别 → 字段解析 → 数据落库 → 排行聚合 → 平台同步。
- **增强层**（LLM）：总结 / 鼓励 / 建议 / 打卡点评 / @问答，失败一律返回 `None`，调用方降级到模板文案。

这样即使没有 key、断网、模型改版，机器人的查询 / 打卡 / 排行功能始终可用。

### 4.2 隐私最小化

- 发给 LLM 的**只有聚合后的数字**，绝不发送原始消息、截图、账号密码。
- 成员账号凭据按 QQ 号隔离存于 `data/accounts/`，只在私聊中收集。
- OCR 用本地模型，图片不离开本机。

### 4.3 每用户独立绑定

运动平台凭据是「一人一账号」，按 QQ 号作为主键区分。绑定后查询固定返回该成员自己的平台数据，互不串扰。

### 4.4 稳定性优先

针对实测踩过的坑做了显式防护：

- **跨线程 Session**：SQLAlchemy 的 `Session` 非线程安全，`asyncio.to_thread` 里不共享同一 Session；SQLite 写入极快，直接在当前协程同步执行。
- **截图去重**：NapCat 偶发发送超时会诱导用户重发同一张图，用「图片 MD5（字节级）+ dHash（感知级，抗转发二次压缩）」做 24 小时窗口、**全局跨成员**去重，避免重复累计里程；去重**只对未绑定平台成员生效**（绑定成员截图本就不写库），且前置到 OCR/视觉之前，命中即跳过、不再重复识别与上传。
- **视觉按需兜底**：本地 OCR 是主路径，仅当「读不出距离」或「识别结果可疑（距离/时长速度超限、每公里消耗离谱）」时才把**该张**截图发给视觉模型复核一次，兼顾「截图不出本机」与识别准确性。
- **解析兜底**：OCR 与解析各包 try/except，识别不出数据时静默跳过，不拖垮整条 handler。
- **发送超时误报**：`finish()` 抛出的 `ActionFailed` / `FinishedException` 单独 re-raise，不误报为「业务失败」。

## 5. 数据模型

| 模型 | 主键 / 约束 | 用途 |
|---|---|---|
| `Member` | `qq`（PK） | 成员：绑定平台、平台账号、QQ 昵称 |
| `DailyRecord` | `(member_qq, record_date, platform)` 唯一 | 每日运动明细（供排行 / 汇总） |
| `ManualDistance` | `member_qq`（PK） | 截图成员的累计里程 + 本周累计 |
| `Group` | `group_id`（PK） | 机器人出现过的群（播报定位目标） |
| `CheckinDay` | `(member_qq, record_date)` 唯一 | 打卡日（累计 / 本月打卡天数） |
| `CheckinLog` | 自增 id | 截图打卡明细（供「删除打卡」精确回退） |
| `CheckinState` | `key`（PK） | 触发幂等标记（里程碑 / 礼物 / 抽奖 / 节日 / 活动） |
| `Activity` | 自增 id | 跑团活动（manual 手动 / cancel 取消固定） |

- 原始明细 `daily_record` 按 `settings.retention_days` 滚动保留（默认 **365 天**），供个人复盘 / 历史查询。
- 周榜 / 月榜**直接由明细聚合**（`compute_range_rankings`）。

## 6. 关键数据流

### 6.1 绑定（Garmin / COROS）

```
成员发「绑定 garmin」→ 私聊填邮箱密码 → 校验登录 → 存 credentials → 后台回填 31 天历史
成员发「绑定 coros」→ 私聊收授权链接 → 浏览器 OAuth → 「绑定确认」→ 存 token → 后台回填历史
```

### 6.2 查询「今日」

```
已绑定：sync_daily(member, today) → provider.fetch_daily → upsert daily_record → 格式化
未绑定：读当日截图明细 + ManualDistance 累计里程 → 格式化（含引导文案）
```

### 6.3 截图打卡（图片 → 数据存储）

```
下载图片 → 尺寸过滤（表情包拦截 / 超大文件跳过）→ 读绑定状态（去重只对未绑定成员）
  ↓ 未绑定平台
MD5 + dHash 去重（命中即跳过：不 OCR、不上传、不落盘）→ 保存原始图 →
本地 RapidOCR 识别 → parse_activity_from_boxes（坐标关联）→ parse_activity（文本兜底）→
【按需】视觉兜底（仅当 OCR 读不出距离 / 识别结果可疑时，才上传该张截图做一次复核）→
sanitize_activity（范围 + 速度 + 卡路里交叉校验）→
写入 daily_record + ManualDistance → LLM 打卡点评（失败降级）
  ↓ 已绑定平台
截图只回显：不写库、不触发视觉（数据以平台接口自动同步为准）
```

### 6.4 排行与播报

```
compute_range_rankings(start, end) → 按距离 / 爬升聚合（月榜追加运动天数）→
每日 23:00 播今日榜；周日追加周榜；月末追加月榜（分段独立发送）
```

### 6.5 调度

单个常驻 asyncio 循环（`services/tasks.py` 的 `start_scheduler`）：

- `_daily_broadcast_loop`：每天 23:00（`BROADCAST_HOUR/MINUTE`）执行 `_run_broadcast`，
  依次做：清理过期明细 → 同步今日数据 → 计算并播报排行 → 群抽奖兜底 →
  活动前一天提醒 → 月末发下月跑团日历。

## 7. 安全与隐私约束

> 以下为项目硬性约束，任何改动都必须遵守：

- 不得读取 / 暴露 `.env`（文档只以 `.env.example` 为模板）。
- 不得用移动 App 的 API 密码方式登录 COROS（一律走官方 OAuth 授权码 + PKCE）。
- 成员账号密码绝不出现在群里：Garmin 必须私聊绑定，COROS 必须私聊授权链接。
- 不打印 / 暴露 `passkey.json` 与 NapCat WebUI token。
- `.env`、`data/`、缓存目录已加入 `.gitignore`，不入库。

## 8. 当前状态（已完成）

- ✅ Garmin / COROS 双平台接入，每用户独立绑定（华为 / Suunto 已彻底移除）。
- ✅ 截图 OCR 打卡（含去重、尺寸过滤、坐标解析、文本兜底）。
- ✅ 今日 / 周数据 / 月数据 / 总结 / 鼓励我 / 建议 查询。
- ✅ 训练诊断（`诊断`）：ACWR 负荷 / 恢复信号 / 配速趋势 + 附比赛成绩算 VO₂max / 成绩预测（运动科学确定性公式，非 LLM）。
- ✅ 今日榜 / 周榜 / 月榜 + 定时播报（周日 / 月末自动追加）。
- ✅ 活动播报（跑团日历）：固定周三例训 / 周五例跑自动进日历 + 手动活动覆盖 / 取消 + 每月末发下月日历图 + 活动前一天 23:00 提醒（管理员隐藏命令）。
- ✅ Agnes AI 增强层（总结 / 鼓励 / 建议 / 问答 / 打卡点评，失败降级模板）。
- ✅ 抽奖 / 骰子 / 随机数 互动玩法。
- ✅ 代码规范化：ruff 格式化 + 静态检查全过，`pyproject.toml` 依赖补全。

## 9. 路线图（规划中）

| 优先级 | 事项 | 说明 |
|---|---|---|
| 高 | Docker 化 | 补 `Dockerfile` + `docker-compose.yml`，降低部署门槛 |
| 高 | 单元测试 | `parsers` / `ranking` / `retention` / `summary` 等纯函数先覆盖 |
| 中 | CI 流水线 | GitHub Actions：`ruff check` + `compileall` + 测试 |
| 中 | 训练负荷进阶 | 基于 `training_load` 做趋势 / 恢复建议（注意不编造医学结论） |
| 低 | 更多平台 | 有官方开放接口时再评估（如 Keep、悦跑圈等） |
| 低 | LICENSE 选择 | 开源前确定许可协议 |

## 10. 历史决策记录

- **华为 / Suunto 移除**：无稳定开放接口、维护成本高，改为「截图 OCR」统一兜底。
- **截图成员也进排行**：未绑定成员的发图记录写入 `daily_record`（`platform="manual"`），与平台成员同榜竞技。
- **`weekly_stat` 保留但不再用于排行**：改为「明细保留 365 天 + 直接聚合」，避免周清理误删月榜数据；`aggregate_week` 幂等写入保留，无害。
- **OCR 保持默认模型**：PP-OCRv5 中文精确匹配率反而低于默认的 PP-OCRv4 mobile，不做无收益替换；优化重心放在「按坐标关联标签与数值」。
