"""COROS 运动记录解析测试：只统计跑步类（100/102/103），游泳/骑行等跳过。"""

from app.services.providers.coros import CorosProvider


def test_parse_sport_records_filters_running_only():
    text = (
        "(3 records)\n"
        "Duration: 40:00 | Distance: 8.00 km\n"
        "Average Pace: 5:00 /km | Avg HR: 160 bpm | Calories: 598 kcal\n"
        "LabelId: 4803 | SportType: 100\n"
        "\n"
        "Duration: 30:00 | Distance: 2.00 km\n"
        "Average Pace: 15:00 /km | Avg HR: 120 bpm | Calories: 200 kcal\n"
        "LabelId: 4804 | SportType: 302\n"  # 游泳（非跑步）
        "\n"
        "Duration: 1:00:00 | Distance: 25.00 km\n"
        "Average Pace: 2:24 /km | Avg HR: 140 bpm | Calories: 900 kcal\n"
        "LabelId: 4805 | SportType: 200\n"  # 骑行（非跑步）
    )
    r = CorosProvider._parse_sport_records(text)

    assert r["total_distance_km"] == 8.0  # 只算跑步 8km
    assert r["total_calories"] == 598  # 只算跑步 598 kcal（游泳/骑行不计）
    assert r["count"] == 1
    assert r["max_distance_km"] == 8.0
    assert r["avg_pace_sec_per_km"] == 300.0  # 40:00 / 8km
    assert r["avg_hr"] == 160
    assert r["activities"] == [("4803", 100)]


def test_parse_sport_records_trail_and_track_counted():
    # 越野跑 102 / 场地跑 103 也算跑步
    text = (
        "(2 records)\n"
        "Duration: 50:00 | Distance: 10.00 km\n"
        "Average Pace: 5:00 /km | Avg HR: 150 bpm\n"
        "LabelId: 1 | SportType: 102\n"
        "\n"
        "Duration: 20:00 | Distance: 4.00 km\n"
        "Average Pace: 5:00 /km | Avg HR: 145 bpm\n"
        "LabelId: 2 | SportType: 103\n"
    )
    r = CorosProvider._parse_sport_records(text)
    assert r["total_distance_km"] == 14.0
    assert r["count"] == 2
    assert r["activities"] == [("1", 102), ("2", 103)]


def test_parse_sport_records_treadmill_and_hiking_counted():
    # 跑步机 101 / 徒步 104 也算跑动类
    text = (
        "(2 records)\n"
        "Duration: 30:00 | Distance: 5.00 km\n"
        "Average Pace: 6:00 /km | Avg HR: 140 bpm\n"
        "LabelId: 1 | SportType: 101\n"  # 跑步机
        "\n"
        "Duration: 1:00:00 | Distance: 6.00 km\n"
        "Average Pace: 10:00 /km | Avg HR: 120 bpm\n"
        "LabelId: 2 | SportType: 104\n"  # 徒步
    )
    r = CorosProvider._parse_sport_records(text)
    assert r["total_distance_km"] == 11.0
    assert r["count"] == 2
    assert r["activities"] == [("1", 101), ("2", 104)]


def test_parse_sport_records_empty():
    assert CorosProvider._parse_sport_records("") == {
        "total_distance_km": 0.0,
        "total_calories": 0,
        "count": 0,
        "max_distance_km": 0.0,
        "avg_pace_sec_per_km": 0.0,
        "avg_hr": 0,
        "activities": [],
    }


def test_parse_sport_records_uses_average_pace_field():
    # 配速应以官方「Average Pace」（移动配速）为准，而不是 Duration/Distance（含暂停的 elapsed）。
    # 这里 elapsed 42:00 / 8km = 5:15，但 Average Pace 是 5:00，应以 5:00（300s）为准。
    text = (
        "Duration: 42:00 | Distance: 8.00 km\n"
        "Average Pace: 5:00 /km | Avg HR: 160 bpm | Calories: 598 kcal\n"
        "LabelId: 4803 | SportType: 100\n"
    )
    r = CorosProvider._parse_sport_records(text)
    assert r["avg_pace_sec_per_km"] == 300.0  # 5:00，不是 42*60/8=315


def test_parse_sport_records_avg_hr_skips_missing():
    # 一条无心率（缺 Avg HR）的记录不应把平均心率拉低。
    text = (
        "Duration: 30:00 | Distance: 5.00 km\n"
        "Average Pace: 6:00 /km | Avg HR: 150 bpm\n"
        "LabelId: 1 | SportType: 100\n"
        "\n"
        "Duration: 30:00 | Distance: 5.00 km\n"
        "Average Pace: 6:00 /km\n"  # 无 Avg HR → hr=0
        "LabelId: 2 | SportType: 100\n"
    )
    r = CorosProvider._parse_sport_records(text)
    assert r["avg_hr"] == 150  # 只按有心率的记录算，不被 0 拉低


def test_parse_activity_ascent_outdoor_gain_loss():
    # 户外跑：Elevation Gain / Loss 格式，取 Gain 侧
    text = "Workout Time: 40:00\nDistance: 8.00 km\nElevation Gain / Loss: 6 m / 0 m"
    assert CorosProvider._parse_activity_ascent(text) == 6.0


def test_parse_activity_ascent_treadmill_total_ascent():
    # 跑步机/室内跑：Total Ascent 格式（坡度估算爬升）
    text = (
        "Indoor Run Activity Details\nDistance: 15.00 km\nTotal Ascent: 972 m\nCalories: 839 kcal"
    )
    assert CorosProvider._parse_activity_ascent(text) == 972.0


def test_parse_activity_ascent_empty():
    assert CorosProvider._parse_activity_ascent("") == 0.0
    assert CorosProvider._parse_activity_ascent("Distance: 5.00 km\nCalories: 200 kcal") == 0.0
